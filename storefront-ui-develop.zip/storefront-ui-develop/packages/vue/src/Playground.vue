<template>
  <div id="playground"></div>
</template>

<script>
// Use this component to play with other components
export default {};
</script>
