# component-description
Gallery with one main and few side pictures that use can browse through.

# storybook-iframe-height
28rem