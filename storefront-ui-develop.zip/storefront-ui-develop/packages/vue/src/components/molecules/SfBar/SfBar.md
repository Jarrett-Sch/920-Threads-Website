# component-description
Bar component for mobile components.

# storybook-iframe-height
4rem
