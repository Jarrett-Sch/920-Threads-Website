# component-description
Customer review component with author, rating, date and review text.

# storybook-iframe-height
10rem