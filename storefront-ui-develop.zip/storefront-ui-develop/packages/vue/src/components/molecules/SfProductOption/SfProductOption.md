# component-description
Component with label used as part of product description. 

# storybook-iframe-height
5rem