# component-description
Component for displaying information with title, image and action button

# storybook-iframe-height
5rem
