# component-description
Modal component with overlay. Example usage can involve many cases like informative or decision dialogue.

# storybook-iframe-height
10rem