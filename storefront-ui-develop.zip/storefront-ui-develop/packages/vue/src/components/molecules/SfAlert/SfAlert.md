# component-description
Component for displaying brief information of varying importance to the user, enriched with an icon.

# storybook-iframe-height
5rem
