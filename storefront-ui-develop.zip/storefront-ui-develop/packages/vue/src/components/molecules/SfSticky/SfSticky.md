# component-description
Applies sticky property to the component.

# storybook-iframe-height
20rem