# component-description
Filter component with color, name and counter of items.

# storybook-iframe-height
3rem