# component-description
Checkbox component

# storybook-iframe-height
3rem
