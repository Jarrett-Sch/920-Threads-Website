# component-description
Component with text and counter, usable for menus and listing.

# storybook-iframe-height
2rem