# component-description
Search bar component with placeholder text and icon.

# storybook-iframe-height
6rem