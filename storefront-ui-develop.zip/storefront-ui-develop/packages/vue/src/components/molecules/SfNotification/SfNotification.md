# component-description
Component used for informative function f.e products added to cart or successful login.

# storybook-iframe-height
5rem