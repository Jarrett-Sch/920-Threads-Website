# component-description
CTA component with button and text

# storybook-iframe-height
5rem