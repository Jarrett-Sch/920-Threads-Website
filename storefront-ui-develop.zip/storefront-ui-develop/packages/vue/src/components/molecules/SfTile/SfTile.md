# component-description
Tile component with text and background-image

# storybook-iframe-height
10rem