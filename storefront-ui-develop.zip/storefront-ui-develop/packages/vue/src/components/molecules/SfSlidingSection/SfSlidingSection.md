# component-description
Section for content with sliding property.

# storybook-iframe-height
25rem