# component-description
Banner component which features various text levels, a background and a [button](button.html).

# storybook-iframe-height
10rem
