# component-description
Pagination component with indicators. 

# storybook-iframe-height
5rem