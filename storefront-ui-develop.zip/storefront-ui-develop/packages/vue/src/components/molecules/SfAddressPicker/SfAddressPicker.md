# component-description
Component for displaying information about address

# storybook-iframe-height
5rem
