# component-description
Scrollable wrapper with styled bar and toggle button.

# storybook-iframe-height
15rem