# component-description
Component for displaying information about categories

# storybook-iframe-height
5rem
