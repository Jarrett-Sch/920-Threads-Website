# component-description
Full-width section for content.

# storybook-iframe-height
35rem