# component-description
Component with icon and text used for describing product characteristics.

# storybook-iframe-height
5rem