# component-description
On click input select field with dropdown

# storybook-iframe-height
10rem