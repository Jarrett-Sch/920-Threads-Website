# component-description
Stepper component increasing dynamically on click. Used to guide user through defined path.

# storybook-iframe-height
25rem