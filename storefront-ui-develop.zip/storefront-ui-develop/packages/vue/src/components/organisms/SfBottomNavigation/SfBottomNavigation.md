# component-description
Full-width fixed bottom navigation component with items and circle icon.

# storybook-iframe-height
8rem