# component-description
Accordion component. Can be set as one or multiple opened, with or without icon. 

# storybook-iframe-height
20rem