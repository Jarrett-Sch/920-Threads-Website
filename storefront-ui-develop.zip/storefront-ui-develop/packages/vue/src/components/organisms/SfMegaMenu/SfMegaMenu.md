# component-description
MegaMenu component for page navigation.

# storybook-iframe-height
10rem
