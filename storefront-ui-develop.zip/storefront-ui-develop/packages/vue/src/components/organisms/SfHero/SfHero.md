# component-description
Full-width hero component with autoplay and navigation arrows.

# storybook-iframe-height
15rem