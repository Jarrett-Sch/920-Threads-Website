# component-description
Full width grid made with banners.

# storybook-iframe-height
40rem