# component-description
Footer component.

# storybook-iframe-height
25rem
