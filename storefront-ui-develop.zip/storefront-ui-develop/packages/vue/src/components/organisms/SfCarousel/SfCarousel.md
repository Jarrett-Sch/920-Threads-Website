# component-description
Carousel component with swipe and arrow navigation.

# storybook-iframe-height
20rem