# component-description
Sidebar component disabling on Cancel button click.

# storybook-iframe-height
35rem