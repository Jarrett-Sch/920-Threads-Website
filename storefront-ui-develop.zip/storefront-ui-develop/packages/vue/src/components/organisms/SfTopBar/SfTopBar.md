# component-description
Top Bar component with righ or left aligned content.

# storybook-iframe-height
10rem