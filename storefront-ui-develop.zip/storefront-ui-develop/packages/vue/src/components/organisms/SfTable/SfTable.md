# component-description
Table component with inner rows, headers and data.

# storybook-iframe-height
25rem