# component-description
Component with tab-related content.

:::warning
There may be an **error** related to SfTab removal (you can find the associated issue [HERE](https://github.com/DivanteLtd/storefront-ui/issues/1206)). The [vue-fragment](https://github.com/Thunberg087/vue-fragment) library we use in SfTab is probably no longer maintained, because the fragments will be a native feature in Vue 3. **Storefront UI** will be rewritten to **Vue 3** soon, this error should no longer occur in the future.
:::

# storybook-iframe-height
30rem