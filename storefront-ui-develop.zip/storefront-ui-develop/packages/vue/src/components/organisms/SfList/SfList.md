# component-description
Vertical list component.

# storybook-iframe-height
6rem