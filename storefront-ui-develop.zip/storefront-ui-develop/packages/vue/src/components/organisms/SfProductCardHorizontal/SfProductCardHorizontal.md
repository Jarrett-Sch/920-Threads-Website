# component-description
Product card horizontal component with image, description, rating and add to cart button.

# storybook-iframe-height
30rem