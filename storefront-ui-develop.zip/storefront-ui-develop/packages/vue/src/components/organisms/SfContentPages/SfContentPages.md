# component-description
Content Pages for static content

# storybook-iframe-height
20rem
