# component-description
Tile component with image, descriptions and actions for collected product.

# storybook-iframe-height
10rem