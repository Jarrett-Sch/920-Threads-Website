# component-description
Product card component with image, description and rating.

# storybook-iframe-height
25rem