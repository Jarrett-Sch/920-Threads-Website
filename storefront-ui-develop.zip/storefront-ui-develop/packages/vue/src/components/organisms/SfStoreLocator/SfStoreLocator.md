# component-description
Component locating and marking on map using tile data.

# storybook-iframe-height
45rem