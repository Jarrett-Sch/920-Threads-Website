# component-description
Grouped Product component

# storybook-iframe-height
30rem
