# component-description
Bullet-style indicator for paginated view containers.

# storybook-iframe-height
3.5rem
