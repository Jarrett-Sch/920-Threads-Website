# component-description
Component with input to choose numeric values and describe quantity.

# storybook-iframe-height
3rem
