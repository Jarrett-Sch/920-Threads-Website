# component-description
Component for listing properties of a product.

# storybook-iframe-height
3rem
