# component-description
Image accepting string source and an array of srcsets (with breakpoints( and widths) or resolutions)

# storybook-iframe-height
25rem