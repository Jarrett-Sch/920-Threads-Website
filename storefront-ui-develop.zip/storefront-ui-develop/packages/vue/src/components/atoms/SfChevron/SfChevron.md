# component-description
Chevron component

# storybook-iframe-height
3rem
