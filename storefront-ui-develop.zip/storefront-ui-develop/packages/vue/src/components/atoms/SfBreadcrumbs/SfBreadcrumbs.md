# component-description
Component which renders a breadcrumb with router links for indicating the level of navigation the user is currently in.

# storybook-iframe-height
3.5rem
