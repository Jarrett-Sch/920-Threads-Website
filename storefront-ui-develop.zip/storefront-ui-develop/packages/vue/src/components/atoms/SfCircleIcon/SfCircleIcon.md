# component-description
Round hover-animated component with an icon, e.g. usable for major navigation/action items.

# storybook-iframe-height
5.5rem
