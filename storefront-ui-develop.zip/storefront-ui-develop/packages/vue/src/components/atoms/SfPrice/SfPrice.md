# component-description
Price information component with optional display of previous price.

# storybook-iframe-height
4rem
