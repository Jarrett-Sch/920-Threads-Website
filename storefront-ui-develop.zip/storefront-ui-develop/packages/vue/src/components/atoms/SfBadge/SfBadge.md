# component-description
Badge component. Place desired content into its default slot.

# storybook-iframe-height
3rem
