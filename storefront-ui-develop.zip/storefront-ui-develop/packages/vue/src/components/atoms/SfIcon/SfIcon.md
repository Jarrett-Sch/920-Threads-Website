# component-description
Icon with color and size modifiers

# storybook-iframe-height
3rem
