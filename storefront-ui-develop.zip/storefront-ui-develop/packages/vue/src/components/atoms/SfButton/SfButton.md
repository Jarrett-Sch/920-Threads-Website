# component-description
Base button component.

# storybook-iframe-height
4.5rem
