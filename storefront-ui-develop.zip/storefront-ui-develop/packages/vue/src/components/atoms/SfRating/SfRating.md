# component-description
Component for displaying score-based user ratings.

# storybook-iframe-height
3rem
