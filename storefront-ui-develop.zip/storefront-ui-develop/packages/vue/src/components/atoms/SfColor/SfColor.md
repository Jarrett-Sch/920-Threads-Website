# component-description
Color picker component button

# storybook-iframe-height
10rem
