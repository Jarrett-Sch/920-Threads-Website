# component-description
Input form field with validation and built-in label animation

# storybook-iframe-height
5rem
