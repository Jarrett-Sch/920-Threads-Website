# component-description
Overlay loading spinner, wrapped around elements for indicating long running tasks like image loading

# storybook-iframe-height
25rem
