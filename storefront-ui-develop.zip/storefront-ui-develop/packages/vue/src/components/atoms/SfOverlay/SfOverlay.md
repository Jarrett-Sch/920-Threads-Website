# component-description
Fullscreen overlay, emitting click events. 

# storybook-iframe-height
5rem
