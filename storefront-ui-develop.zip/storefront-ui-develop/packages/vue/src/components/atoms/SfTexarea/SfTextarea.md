# component-description
Multi-line text input control

# storybook-iframe-height
5rem
