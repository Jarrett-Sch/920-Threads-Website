# component-description
Divider component

# storybook-iframe-height
3rem
