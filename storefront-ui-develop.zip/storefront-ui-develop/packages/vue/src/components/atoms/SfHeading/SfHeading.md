# component-description
Heading component for titles with optional description

# storybook-iframe-height
6.5rem
