# component-description
Arrow component for sliders and navigation.

# storybook-iframe-height
5rem
