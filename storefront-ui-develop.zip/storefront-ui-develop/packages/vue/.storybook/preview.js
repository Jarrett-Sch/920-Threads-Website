import "../styles.scss";

export const parameters = {
  actions: { argTypesRegex: "^on[A-Z].*" },
}