"use strict";

const { createIndexFiles } = require("./create-index-files");

function runVersion() {
  createIndexFiles();
}

runVersion();
